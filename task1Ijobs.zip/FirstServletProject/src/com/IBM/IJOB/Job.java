package com.IBM.IJOB;

public class  Job extends Thread implements Ijob {
	String name;

	public Job(String n) {
		name = n;
		
	}

	public void execute() {
		System.out.println("New" + name + " "+Thread.currentThread().getName());
	}

	@Override
	public void run() {
		this.execute();
	}
}
