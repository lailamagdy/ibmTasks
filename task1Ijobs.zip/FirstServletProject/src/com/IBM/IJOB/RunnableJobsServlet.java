
package com.IBM.IJOB;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(description = "My First Servlet", urlPatterns = { "/FirstServlet" , "/FirstServlet.do"}, initParams = {@WebInitParam(name="id",value="1"),@WebInitParam(name="name",value="pankaj")})
public class RunnableJobsServlet extends HttpServlet  {
	private static final long serialVersionUID = 1L;
	
	Thread thread;
       
    
    public RunnableJobsServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {			
		doPost(request,response);
	}
		
		

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		response.setContentType("text/html;charset=UTF-8");
		 
		String name=request.getParameter("name");
		int numberofjobs = Integer.parseInt(name);
		String nameT=request.getParameter("nameT");
		int numberofthreads = Integer.parseInt(nameT);
		ExecutorService executor = Executors.newFixedThreadPool(numberofthreads);
		
		for(int i=0;i<numberofjobs;i++) {
			Job job=new Job("job"+i);
			executor.submit(job);
			 response.getWriter().println("starting job" + ": " + i);		 		
		}
			
		
	}

	
}
 