package com.IBM.IJOB;

public interface Ijob {
public void execute();
}
